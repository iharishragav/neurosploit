import os
import sys
import time
import requests
from termcolor import colored
import pyfiglet
from .core import run_mock_recon, build_ai_prompt
import threading
import itertools



def loading_effect(text):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.002)
    print()

def main():
    banner = colored(pyfiglet.figlet_format("NeuroSploit", font="slant"), 'red')
    loading_effect(banner)
    print(colored("By Kamalesh  |  AI Recon Assistant", 'yellow'))
    print(colored("=" * 60, 'cyan'))

    # Select input type
    print("Select input type:")
    print("1. Single domain")
    print("2. List of domains (file)")
    choice = input("> ")

    targets = []
    if choice.strip() == "1":
        domain = input("Enter domain (e.g., glean.com): ").strip()
        targets = [domain]
    elif choice.strip() == "2":
        path = input("Enter path to file: ").strip()
        if os.path.exists(path):
            with open(path, "r") as f:
                targets = [line.strip() for line in f if line.strip()]
        else:
            print("❌ File not found.")
            return
    else:
        print("❌ Invalid choice.")
        return

    all_results = []
    for domain in targets:
        print(f"\n🔍 Recon on {domain} ...")
        recon_data = run_mock_recon(domain)  # You can replace this later
        all_results.append(build_ai_prompt(domain, recon_data))

    # Send to AI
    final_prompt = "\n\n".join(all_results)
    prompt_path = os.path.join(os.path.dirname(__file__), "prompts", "analysis_prompt.txt")
    with open(prompt_path, "r") as f:
        base_prompt = f.read()
    complete_prompt = base_prompt + "\n\n" + final_prompt

    

    def spinner():
        for c in itertools.cycle(['|', '/', '-', '\\']):
            if not loading:
                break
            sys.stdout.write(f'\r🧠 Thinking... {c}')
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write('\r' + ' ' * 30 + '\r')
    
    # Ask user to select model
    model = input("Choose AI model [phi/mistral/gemma] (default: phi): ").strip() or "phi"
    
    loading = True
    t = threading.Thread(target=spinner)
    t.start()
    
    start_time = time.time()
    
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": complete_prompt, "stream": False},
            timeout=180
        )
        end_time = time.time()
        loading = False
        t.join()
    
        result = response.json()
        print(f"\n✅ AI responded in {round(end_time - start_time, 2)} seconds.\n")
        print("🧠 AI Suggestions:\n")
        print(result["response"])
    
    except Exception as e:
        loading = False
        t.join()
        print("\n❌ Error contacting AI engine:", e)
    
    