def run_mock_recon(domain):
    # Simulate recon results
    return {
        "subdomains": [f"app.{domain}", f"api.{domain}", f"admin.{domain}"],
        "tech_stack": {
            "Web Server": "nginx",
            "Framework": "React",
            "CDN": "Cloudflare"
        }
    }

def build_ai_prompt(domain, data):
    subdomains = "\n".join(data["subdomains"])
    stack = "\n".join([f"{k}: {v}" for k, v in data["tech_stack"].items()])

    return f"""
📌 Domain: {domain}

🧷 Subdomains Discovered:
{subdomains}

🧱 Tech Stack:
{stack}

Suggest possible vulnerabilities and attack paths for the above target.
"""

